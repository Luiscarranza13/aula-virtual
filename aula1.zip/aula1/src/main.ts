import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    bufferLogs: true,
  });

  // Validaciones globales
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: false,
      transform: true,
    }),
  );

  // CORS (ajusta cuando tengas Netlify)
  app.enableCors({
    origin: [
      'http://localhost:3000',
      // 'https://tu-frontend.netlify.app',
    ],
    credentials: true,
  });

  // Puerto dinámico para Railway + fallback para local
  const port = process.env.PORT
    ? Number(process.env.PORT)
    : Math.floor(Math.random() * (49151 - 3001 + 1)) + 3001; // evita EADDRINUSE

  await app.listen(port, '0.0.0.0');

  console.log(`🚀 Servidor NestJS corriendo en http://localhost:${port}`);
}

bootstrap();
